# Adım — Flutter məşq tətbiqi

## Quraşdırma
1. ZIP faylını aç.
2. Layihənin kök qovluğunda terminal aç.
3. `flutter pub get` işlət.
4. `flutter run` ilə tətbiqi başlad.

## Qeyd
- Həftəlik statistika `shared_preferences` ilə cihazda saxlanılır.
- Bir gündə bir neçə məşq tamamlansa da, həftəlik göstəricidə həmin gün bir dəfə sayılır.
- Lottie animasiyaları internet bağlantısı tələb edir.
- Bu arxivdə `lib/` və `pubspec.yaml` var. Android/iOS platforma qovluqları üçün `flutter create .` işlətmək olar.
