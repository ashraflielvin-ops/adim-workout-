import 'package:shared_preferences/shared_preferences.dart';

class ProgressService {
  static const _datesKey = 'completed_workout_dates';

  static String _dateKey(DateTime date) {
    final d = DateTime(date.year, date.month, date.day);
    return '${d.year.toString().padLeft(4, '0')}-'
        '${d.month.toString().padLeft(2, '0')}-'
        '${d.day.toString().padLeft(2, '0')}';
  }

  static DateTime _mondayOf(DateTime date) {
    final day = DateTime(date.year, date.month, date.day);
    return day.subtract(Duration(days: day.weekday - DateTime.monday));
  }

  static Future<int> getWeeklyProgress() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(_datesKey) ?? <String>[];
    final today = DateTime.now();
    final monday = _mondayOf(today);
    final sunday = monday.add(const Duration(days: 6));

    final validDates = saved.where((value) {
      final parsed = DateTime.tryParse(value);
      if (parsed == null) return false;
      final date = DateTime(parsed.year, parsed.month, parsed.day);
      return !date.isBefore(monday) && !date.isAfter(sunday);
    }).toSet().toList()
      ..sort();

    if (validDates.length != saved.length) {
      await prefs.setStringList(_datesKey, validDates);
    }
    return validDates.length;
  }

  static Future<int> recordCompletedWorkout() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(_datesKey) ?? <String>[];
    final today = _dateKey(DateTime.now());
    if (!saved.contains(today)) saved.add(today);
    await prefs.setStringList(_datesKey, saved);
    return getWeeklyProgress();
  }
}
