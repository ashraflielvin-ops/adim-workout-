import 'package:flutter/material.dart';
import '../data/workouts_data.dart';
import '../models/workout_model.dart';
import 'workout_screen.dart';

class WorkoutSelectScreen extends StatefulWidget {
  final String? currentFeeling;

  const WorkoutSelectScreen({super.key, this.currentFeeling});

  @override
  State<WorkoutSelectScreen> createState() => _WorkoutSelectScreenState();
}

class _WorkoutSelectScreenState extends State<WorkoutSelectScreen> {
  String selectedLevel = 'Hamısı';

  List<WorkoutModel> get filteredWorkouts {
    if (selectedLevel == 'Hamısı') return allWorkouts;
    return allWorkouts.where((workout) => workout.level == selectedLevel).toList();
  }

  @override
  void initState() {
    super.initState();
    if (widget.currentFeeling == 'Yorğun') {
      selectedLevel = 'Asan';
    } else if (widget.currentFeeling == 'Normal') {
      selectedLevel = 'Orta';
    } else if (widget.currentFeeling == 'Yaxşı' || widget.currentFeeling == 'Güclü') {
      selectedLevel = 'Hamısı';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Məşq seç')),
      body: Column(
        children: [
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: ['Hamısı', 'Asan', 'Orta', 'Çətin']
                  .map(_buildFilterChip)
                  .toList(),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: filteredWorkouts.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        '$selectedLevel səviyyəsində hələ məşq əlavə edilməyib.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade700, fontSize: 16),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: filteredWorkouts.length,
                    itemBuilder: (context, index) => _buildWorkoutCard(filteredWorkouts[index]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label) {
    final selected = selectedLevel == label;
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => selectedLevel = label),
        selectedColor: Colors.green,
        backgroundColor: Colors.white,
        labelStyle: TextStyle(
          color: selected ? Colors.white : Colors.black87,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildWorkoutCard(WorkoutModel workout) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => WorkoutScreen(workout: workout)),
            );
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.fitness_center, color: Colors.green, size: 28),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        workout.name,
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${workout.durationInSeconds} saniyə • ${workout.level}',
                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
