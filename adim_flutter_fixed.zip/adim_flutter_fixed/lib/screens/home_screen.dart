import 'package:flutter/material.dart';
import '../services/progress_service.dart';
import 'workout_select_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String selectedFeeling = 'Normal';
  int weeklyProgress = 0;
  bool isLoadingProgress = true;

  final List<Map<String, String>> feelings = const [
    {'label': 'Yorğun', 'emoji': '😴'},
    {'label': 'Normal', 'emoji': '😐'},
    {'label': 'Yaxşı', 'emoji': '😊'},
    {'label': 'Güclü', 'emoji': '💪'},
  ];

  @override
  void initState() {
    super.initState();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    final progress = await ProgressService.getWeeklyProgress();
    if (!mounted) return;
    setState(() {
      weeklyProgress = progress;
      isLoadingProgress = false;
    });
  }

  Future<void> _openWorkoutSelection() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WorkoutSelectScreen(currentFeeling: selectedFeeling),
      ),
    );
    _loadProgress();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Salam!',
                style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 5),
              Text(
                'Bu gün özünə vaxt ayır.',
                style: TextStyle(fontSize: 15, color: Colors.grey.shade600),
              ),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Bu gün nə etmək istəyirsən?',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Əhvalına uyğun məşq seç və hərəkətə başla.',
                      style: TextStyle(fontSize: 14, color: Colors.white70),
                    ),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 49,
                      child: ElevatedButton(
                        onPressed: _openWorkoutSelection,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          foregroundColor: Colors.green.shade800,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        child: const Text(
                          'Məşq seç',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 28),
              const Text(
                'Necə hiss edirsən?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 14),
              Row(
                children: feelings.map((feeling) {
                  final label = feeling['label']!;
                  final selected = selectedFeeling == label;
                  return Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() => selectedFeeling = label),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 2),
                          decoration: BoxDecoration(
                            color: selected ? Colors.green.withValues(alpha: 0.12) : Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected ? Colors.green : Colors.grey.shade300,
                            ),
                          ),
                          child: Column(
                            children: [
                              Text(feeling['emoji']!, style: const TextStyle(fontSize: 25)),
                              const SizedBox(height: 6),
                              FittedBox(
                                child: Text(
                                  label,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                                    color: selected ? Colors.green.shade800 : Colors.black87,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: 58,
                      height: 58,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          CircularProgressIndicator(
                            value: weeklyProgress / 7,
                            strokeWidth: 7,
                            backgroundColor: Colors.grey.shade200,
                            color: Colors.green,
                          ),
                          Center(
                            child: Text(
                              '$weeklyProgress/7',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Bu həftə',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            isLoadingProgress
                                ? 'Statistika yüklənir...'
                                : '$weeklyProgress gün məşq etdin. Əla gedirsən!',
                            style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
