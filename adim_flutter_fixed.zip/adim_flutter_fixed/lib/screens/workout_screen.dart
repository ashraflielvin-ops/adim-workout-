import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../models/workout_model.dart';
import '../services/progress_service.dart';

class WorkoutScreen extends StatefulWidget {
  final WorkoutModel workout;

  const WorkoutScreen({super.key, required this.workout});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _lottieController;
  Timer? _timer;
  late int remainingSeconds;
  bool isPaused = false;
  bool isFinished = false;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    remainingSeconds = widget.workout.durationInSeconds;
    _lottieController = AnimationController(vsync: this);
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    if (isFinished || isPaused) return;

    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || isPaused || isFinished) {
        timer.cancel();
        return;
      }
      if (remainingSeconds <= 1) {
        timer.cancel();
        setState(() {
          remainingSeconds = 0;
          isFinished = true;
        });
        _lottieController.stop();
        _saveCompletion();
      } else {
        setState(() => remainingSeconds--);
      }
    });
  }

  Future<void> _saveCompletion() async {
    if (_isSaving) return;
    _isSaving = true;
    await ProgressService.recordCompletedWorkout();
  }

  void _togglePause() {
    if (isFinished) return;
    setState(() => isPaused = !isPaused);
    if (isPaused) {
      _timer?.cancel();
      _lottieController.stop();
    } else {
      _lottieController.repeat();
      _startTimer();
    }
  }

  void _restartWorkout() {
    _timer?.cancel();
    setState(() {
      remainingSeconds = widget.workout.durationInSeconds;
      isFinished = false;
      isPaused = false;
      _isSaving = false;
    });
    _lottieController.repeat();
    _startTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _lottieController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final progress = 1 - (remainingSeconds / widget.workout.durationInSeconds);

    return Scaffold(
      appBar: AppBar(title: Text(widget.workout.name)),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 10),
            Container(
              height: 280,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.06),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: Lottie.network(
                  widget.workout.lottieUrl,
                  controller: _lottieController,
                  onLoaded: (composition) {
                    _lottieController.duration = composition.duration;
                    if (!isPaused && !isFinished) _lottieController.repeat();
                  },
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) => Center(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.animation, size: 42, color: Colors.grey.shade400),
                          const SizedBox(height: 10),
                          const Text(
                            'Animasiya yüklənmədi.\nİnternet bağlantını yoxla.',
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 28),
            Text(
              isFinished ? 'Məşq bitdi!' : isPaused ? 'Fasilə' : '$remainingSeconds saniyə',
              style: TextStyle(
                fontSize: 36,
                fontWeight: FontWeight.bold,
                color: isFinished ? Colors.green : Colors.black87,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              isFinished
                  ? 'Əla iş gördün! Məşqin tamamlandı.'
                  : isPaused
                      ? 'Hazır olanda davam et.'
                      : 'Hərəkəti sakit və düzgün et.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 18),
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: LinearProgressIndicator(
                value: progress.clamp(0.0, 1.0),
                minHeight: 8,
                backgroundColor: Colors.grey.shade200,
                color: Colors.green,
              ),
            ),
            const Spacer(),
            if (!isFinished)
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton.icon(
                  onPressed: _togglePause,
                  icon: Icon(isPaused ? Icons.play_arrow : Icons.pause),
                  label: Text(isPaused ? 'Davam et' : 'Fasilə ver'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              )
            else
              SizedBox(
                width: double.infinity,
                height: 54,
                child: OutlinedButton.icon(
                  onPressed: _restartWorkout,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Yenidən başla'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.green,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.green,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
                child: Text(isFinished ? 'Ana səhifəyə qayıt' : 'Məşqi bitir'),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}
