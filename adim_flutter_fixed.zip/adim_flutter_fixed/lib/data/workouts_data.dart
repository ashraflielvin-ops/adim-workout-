import '../models/workout_model.dart';

const List<WorkoutModel> allWorkouts = [
  WorkoutModel(
    id: '1',
    name: 'Squat',
    lottieUrl: 'https://assets10.lottiefiles.com/packages/lf20_ydo6yqxf.json',
    durationInSeconds: 40,
    level: 'Orta',
  ),
  WorkoutModel(
    id: '2',
    name: 'Push-up',
    lottieUrl: 'https://assets9.lottiefiles.com/packages/lf20_jR229r.json',
    durationInSeconds: 30,
    level: 'Orta',
  ),
  WorkoutModel(
    id: '3',
    name: 'Plank',
    lottieUrl: 'https://assets5.lottiefiles.com/packages/lf20_4p3a.json',
    durationInSeconds: 45,
    level: 'Asan',
  ),
  WorkoutModel(
    id: '4',
    name: 'Lunges',
    lottieUrl: 'https://assets2.lottiefiles.com/packages/lf20_ytg7s8xu.json',
    durationInSeconds: 40,
    level: 'Orta',
  ),
  WorkoutModel(
    id: '5',
    name: 'Jumping Jack',
    lottieUrl: 'https://assets4.lottiefiles.com/packages/lf20_obhph3sh.json',
    durationInSeconds: 30,
    level: 'Asan',
  ),
  WorkoutModel(
    id: '6',
    name: 'Glute Bridge',
    lottieUrl: 'https://assets1.lottiefiles.com/packages/lf20_jcikwtux.json',
    durationInSeconds: 35,
    level: 'Asan',
  ),
];
