class WorkoutModel {
  final String id;
  final String name;
  final String lottieUrl;
  final int durationInSeconds;
  final String level;

  const WorkoutModel({
    required this.id,
    required this.name,
    required this.lottieUrl,
    required this.durationInSeconds,
    required this.level,
  });
}
